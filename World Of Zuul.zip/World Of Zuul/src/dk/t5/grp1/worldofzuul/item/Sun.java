package dk.t5.grp1.worldofzuul.item;

public class Sun extends Item {

    public Sun(int x, int y) {
        super("Sun", ItemType.SUN, x, y);
    }

    public Sun(){
        super("Sun", ItemType.SUN);
    }
}
