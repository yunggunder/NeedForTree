package dk.t5.grp1.worldofzuul.item;

public class Seed extends Item {

    public Seed(int x, int y) {
        super("Seed", ItemType.SEED, x, y);
    }

    public Seed() {
        super("Seed", ItemType.SEED);
    }
}
