package dk.t5.grp1.worldofzuul.item;

public class NullItem extends Item {

    public NullItem() {
        super("There is no item here", ItemType.NULLITEM);
    }
}
