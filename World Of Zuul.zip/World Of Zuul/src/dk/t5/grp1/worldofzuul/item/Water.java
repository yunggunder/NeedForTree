package dk.t5.grp1.worldofzuul.item;

public class Water extends Item {
    
    public Water(int x, int y) {
        super("Water", ItemType.WATER, x, y);
    }
    public Water() {
        super("Water", ItemType.WATER);
    }
}
