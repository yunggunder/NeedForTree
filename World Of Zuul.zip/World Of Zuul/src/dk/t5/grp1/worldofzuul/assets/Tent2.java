package dk.t5.grp1.worldofzuul.assets;

import dk.t5.grp1.worldofzuul.graphics.Sprite;

public class Tent2 extends Assets {
    public Tent2(int x, int y) {
        super(x, y, Sprite.assetTent2);
    }
}
