package dk.t5.grp1.worldofzuul.assets;

import dk.t5.grp1.worldofzuul.graphics.Sprite;

public class Bridge extends Assets {

    public Bridge(int x, int y) {
        super(x, y, Sprite.assetBridge);
    }
}
