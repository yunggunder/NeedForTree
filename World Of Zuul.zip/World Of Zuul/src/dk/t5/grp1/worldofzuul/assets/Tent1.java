package dk.t5.grp1.worldofzuul.assets;

import dk.t5.grp1.worldofzuul.graphics.Sprite;

public class Tent1 extends Assets {
    public Tent1(int x, int y) {
        super(x, y, Sprite.assetTent1);
    }
}
