package dk.t5.grp1.worldofzuul.question;

public class Question1 extends Question{
    public Question1() {
        super("text/questions/question1.txt", "text/questions/question1a.txt", "text/questions/question1b.txt", "text/questions/question1c.txt", 0);
    }
}
