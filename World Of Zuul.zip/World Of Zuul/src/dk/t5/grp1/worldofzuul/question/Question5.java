package dk.t5.grp1.worldofzuul.question;

public class Question5 extends Question{
    public Question5() {
        super("text/questions/question5.txt", "text/questions/question5a.txt", "text/questions/question5b.txt", "text/questions/question5c.txt", 0);
    }
}
