package dk.t5.grp1.worldofzuul.question;

public class Question6 extends Question{
    public Question6() {
        super("text/questions/question6.txt", "text/questions/question6a.txt", "text/questions/question6b.txt", "text/questions/question6c.txt", 2);
    }
}
