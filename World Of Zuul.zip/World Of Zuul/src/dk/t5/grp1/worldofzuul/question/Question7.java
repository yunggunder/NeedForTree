package dk.t5.grp1.worldofzuul.question;

public class Question7 extends Question{
    public Question7() {
        super("text/questions/question7.txt", "text/questions/question7a.txt", "text/questions/question7b.txt", "text/questions/question7c.txt", 1);
    }
}
