package dk.t5.grp1.worldofzuul.question;

public class Question4 extends Question{
    public Question4() {
        super("text/questions/question4.txt", "text/questions/question4a.txt", "text/questions/question4b.txt", "text/questions/question4c.txt", 0);
    }
}
