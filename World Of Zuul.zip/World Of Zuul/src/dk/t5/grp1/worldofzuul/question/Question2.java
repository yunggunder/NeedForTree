package dk.t5.grp1.worldofzuul.question;

public class Question2 extends Question{
    public Question2() {
        super("text/questions/question2.txt", "text/questions/question2a.txt", "text/questions/question2b.txt", "text/questions/question2c.txt", 2);
    }
}
