package dk.t5.grp1.worldofzuul.question;

public class Question3 extends Question{
    public Question3() {
        super("text/questions/question3.txt", "text/questions/question3a.txt", "text/questions/question3b.txt", "text/questions/question3c.txt", 0);
    }
}
