package dk.t5.grp1.worldofzuul.question;

public class Question8 extends Question{
    public Question8() {
        super("text/questions/question8.txt", "text/questions/question8a.txt", "text/questions/question8b.txt", "text/questions/question8c.txt", 2);
    }
}
